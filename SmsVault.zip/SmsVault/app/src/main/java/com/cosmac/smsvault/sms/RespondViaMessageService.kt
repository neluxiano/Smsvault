package com.cosmac.smsvault.sms

import android.app.Service
import android.content.Intent
import android.os.IBinder

/** Obrigatório para ser app SMS padrão ("responder com mensagem" nas chamadas rejeitadas). */
class RespondViaMessageService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopSelf(startId)   // TODO: enviar o texto recebido em intent.getStringExtra(Intent.EXTRA_TEXT)
        return START_NOT_STICKY
    }
}
