package com.cosmac.smsvault.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (parts.isEmpty()) return

        val address = parts[0].originatingAddress ?: return
        val body = parts.joinToString("") { it.messageBody ?: "" }
        val date = parts[0].timestampMillis

        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val hidden = SmsRepository(context.applicationContext).saveIncoming(address, body, date)
                if (hidden) Notifier.show(context, "Nova mensagem", "", secret = true)
                else Notifier.show(context, address, body, secret = false)
            } finally {
                pending.finish()
            }
        }
    }
}
