package com.cosmac.smsvault.ui

import android.Manifest
import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.cosmac.smsvault.security.VaultSession
import com.cosmac.smsvault.sms.Conversation
import com.cosmac.smsvault.sms.SmsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var repo: SmsRepository
    private lateinit var list: ListView
    private var items = listOf<Conversation>()

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { askDefaultSms() }
    private val roleRequest = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SmsRepository(this)

        // Toque LONGO no título abre o cofre (gesto discreto)
        val title = TextView(this).apply {
            text = "Mensagens"; textSize = 22f; setPadding(32, 40, 32, 24)
            setOnLongClickListener {
                startActivity(Intent(this@MainActivity, VaultActivity::class.java)); true
            }
        }
        list = ListView(this)
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title); addView(list)
        })

        list.setOnItemClickListener { _, _, i, _ -> ThreadActivity.open(this, items[i].address, hidden = false) }
        list.setOnItemLongClickListener { _, _, i, _ -> confirmHide(items[i].address); true }

        permissions.launch(arrayOf(
            Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_CONTACTS,
            Manifest.permission.POST_NOTIFICATIONS
        ))
    }

    override fun onResume() {
        super.onResume()
        VaultSession.lock()   // ao voltar à lista principal, o cofre fecha
        refresh()
    }

    private fun askDefaultSms() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleAvailable(RoleManager.ROLE_SMS) && !rm.isRoleHeld(RoleManager.ROLE_SMS))
            roleRequest.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
        else refresh()
    }

    private fun refresh() {
        lifecycleScope.launch {
            items = try { withContext(Dispatchers.IO) { repo.conversations() } } catch (e: SecurityException) { emptyList() }
            list.adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_list_item_1,
                items.map { "${it.address}\n${it.lastBody.take(60)}" }
            )
        }
    }

    private fun confirmHide(address: String) {
        AlertDialog.Builder(this)
            .setTitle("Mover para o cofre?")
            .setMessage("$address deixa de aparecer na lista e as mensagens passam para o cofre cifrado.")
            .setPositiveButton("Mover") { _, _ ->
                lifecycleScope.launch { withContext(Dispatchers.IO) { repo.hide(address) }; refresh() }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
