package com.cosmac.smsvault.sms

import android.content.ContentValues
import android.content.Context
import android.provider.Telephony
import android.telephony.SmsManager
import com.cosmac.smsvault.data.HiddenContact
import com.cosmac.smsvault.data.VaultDb
import com.cosmac.smsvault.data.VaultMessage

data class Conversation(val address: String, val lastBody: String, val date: Long)
data class Msg(val body: String, val date: Long, val incoming: Boolean)

/** Todas as funções são bloqueantes: chame-as em Dispatchers.IO. */
class SmsRepository(private val ctx: Context) {
    private val dao get() = VaultDb.get(ctx).dao()
    private val cr get() = ctx.contentResolver

    companion object {
        fun key(number: String): String {
            val d = number.filter { it.isDigit() }
            return if (d.length > 9) d.takeLast(9) else d
        }
    }

    fun isHidden(address: String) = dao.isHidden(key(address)) > 0
    fun hiddenContacts(): List<String> = dao.hiddenContacts().map { it.address }

    // ---------- Lista de conversas (sem as escondidas) ----------
    fun conversations(): List<Conversation> {
        val hidden = dao.hiddenKeys().toSet()
        val map = LinkedHashMap<String, Conversation>()
        cr.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
            null, null, "${Telephony.Sms.DATE} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val a = c.getString(0) ?: continue
                val k = key(a)
                if (k in hidden || map.containsKey(k)) continue
                map[k] = Conversation(a, c.getString(1) ?: "", c.getLong(2))
            }
        }
        return map.values.toList()
    }

    fun thread(address: String, hidden: Boolean): List<Msg> {
        val k = key(address)
        if (hidden) return dao.thread(k).map { Msg(it.body, it.date, it.incoming) }
        val out = mutableListOf<Msg>()
        cr.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE),
            "${Telephony.Sms.ADDRESS} LIKE ?", arrayOf("%$k"),
            "${Telephony.Sms.DATE} ASC"
        )?.use { c ->
            while (c.moveToNext())
                out += Msg(c.getString(0) ?: "", c.getLong(1), c.getInt(2) == Telephony.Sms.MESSAGE_TYPE_INBOX)
        }
        return out
    }

    // ---------- Receber ----------
    /** Devolve true se a mensagem foi para o cofre. */
    fun saveIncoming(address: String, body: String, date: Long): Boolean {
        return if (isHidden(address)) {
            dao.insert(VaultMessage(contactKey = key(address), address = address, body = body, date = date, incoming = true))
            true
        } else {
            writeSystem(address, body, date, incoming = true)
            false
        }
    }

    // ---------- Enviar ----------
    fun send(address: String, text: String) {
        val sm = ctx.getSystemService(SmsManager::class.java)
        sm.sendMultipartTextMessage(address, null, sm.divideMessage(text), null, null)
        val now = System.currentTimeMillis()
        if (isHidden(address))
            dao.insert(VaultMessage(contactKey = key(address), address = address, body = text, date = now, incoming = false))
        else
            writeSystem(address, text, now, incoming = false)
    }

    // ---------- Cofre: esconder / mostrar ----------
    fun hide(address: String) {
        val k = key(address)
        dao.hide(HiddenContact(k, address))
        val moved = mutableListOf<VaultMessage>()
        cr.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE),
            "${Telephony.Sms.ADDRESS} LIKE ?", arrayOf("%$k"), null
        )?.use { c ->
            while (c.moveToNext())
                moved += VaultMessage(
                    contactKey = k, address = address, body = c.getString(0) ?: "",
                    date = c.getLong(1), incoming = c.getInt(2) == Telephony.Sms.MESSAGE_TYPE_INBOX
                )
        }
        dao.insertAll(moved)                                   // 1º copia para o cofre...
        cr.delete(Telephony.Sms.CONTENT_URI, "${Telephony.Sms.ADDRESS} LIKE ?", arrayOf("%$k")) // 2º apaga do sistema
    }

    fun unhide(address: String) {
        val k = key(address)
        dao.thread(k).forEach { writeSystem(it.address, it.body, it.date, it.incoming) }
        dao.deleteThread(k)
        dao.unhide(k)
    }

    private fun writeSystem(address: String, body: String, date: Long, incoming: Boolean) {
        val v = ContentValues().apply {
            put(Telephony.Sms.ADDRESS, address)
            put(Telephony.Sms.BODY, body)
            put(Telephony.Sms.DATE, date)
            put(Telephony.Sms.READ, 1)
        }
        cr.insert(if (incoming) Telephony.Sms.Inbox.CONTENT_URI else Telephony.Sms.Sent.CONTENT_URI, v)
    }
}
