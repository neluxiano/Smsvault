package com.cosmac.smsvault.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.cosmac.smsvault.security.VaultKeys
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@Database(entities = [HiddenContact::class, VaultMessage::class], version = 1, exportSchema = false)
abstract class VaultDb : RoomDatabase() {
    abstract fun dao(): VaultDao

    companion object {
        @Volatile private var instance: VaultDb? = null

        fun get(ctx: Context): VaultDb = instance ?: synchronized(this) {
            instance ?: build(ctx.applicationContext).also { instance = it }
        }

        private fun build(ctx: Context): VaultDb {
            System.loadLibrary("sqlcipher")
            val factory = SupportOpenHelperFactory(VaultKeys.dbPassphrase(ctx))
            return Room.databaseBuilder(ctx, VaultDb::class.java, "vault.db")
                .openHelperFactory(factory)
                .build()
        }
    }
}
