package com.cosmac.smsvault.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface VaultDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) fun hide(c: HiddenContact)
    @Query("DELETE FROM hidden_contacts WHERE contactKey = :k") fun unhide(k: String)
    @Query("SELECT COUNT(*) FROM hidden_contacts WHERE contactKey = :k") fun isHidden(k: String): Int
    @Query("SELECT * FROM hidden_contacts") fun hiddenContacts(): List<HiddenContact>
    @Query("SELECT contactKey FROM hidden_contacts") fun hiddenKeys(): List<String>

    @Insert fun insert(m: VaultMessage)
    @Insert fun insertAll(list: List<VaultMessage>)
    @Query("SELECT * FROM vault_messages WHERE contactKey = :k ORDER BY date ASC") fun thread(k: String): List<VaultMessage>
    @Query("DELETE FROM vault_messages WHERE contactKey = :k") fun deleteThread(k: String)
}
