package com.cosmac.smsvault.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Obrigatório para ser app SMS padrão. MMS fica para uma fase seguinte. */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { /* TODO MMS */ }
}
