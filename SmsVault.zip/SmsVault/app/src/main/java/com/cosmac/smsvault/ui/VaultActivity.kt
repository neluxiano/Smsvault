package com.cosmac.smsvault.ui

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.cosmac.smsvault.security.VaultKeys
import com.cosmac.smsvault.security.VaultSession
import com.cosmac.smsvault.sms.SmsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VaultActivity : AppCompatActivity() {
    private lateinit var repo: SmsRepository
    private lateinit var list: ListView
    private var contacts = listOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        title = "Cofre"
        repo = SmsRepository(this)
        list = ListView(this)
        setContentView(list)
        list.setOnItemClickListener { _, _, i, _ -> ThreadActivity.open(this, contacts[i], hidden = true) }
        list.setOnItemLongClickListener { _, _, i, _ -> confirmUnhide(contacts[i]); true }
    }

    override fun onStart() {
        super.onStart()
        if (VaultSession.valid()) load() else authenticate()
    }

    // ---------- Autenticação ----------
    private fun authenticate() {
        if (!VaultKeys.hasPin(this)) { askNewPin(); return }
        val canBio = BiometricManager.from(this).canAuthenticate(BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
        if (!canBio) { askPin(); return }

        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Abrir cofre")
            .setNegativeButtonText("Usar PIN")
            .setAllowedAuthenticators(BIOMETRIC_STRONG)
            .build()
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = unlock()
            override fun onAuthenticationError(code: Int, msg: CharSequence) {
                if (code == BiometricPrompt.ERROR_NEGATIVE_BUTTON) askPin() else finish()
            }
        }).authenticate(info)
    }

    private fun askNewPin() = pinDialog("Criar PIN do cofre (mín. 4 dígitos)") { pin ->
        if (pin.length >= 4) { VaultKeys.setPin(this, pin); unlock() }
        else { Toast.makeText(this, "PIN muito curto", Toast.LENGTH_SHORT).show(); askNewPin() }
    }

    private fun askPin() = pinDialog("PIN do cofre") { pin ->
        if (VaultKeys.checkPin(this, pin)) unlock()
        else { Toast.makeText(this, "PIN errado", Toast.LENGTH_SHORT).show(); askPin() }
    }

    private fun pinDialog(title: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this)
            .setTitle(title).setView(et).setCancelable(false)
            .setPositiveButton("OK") { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton("Cancelar") { _, _ -> finish() }
            .show()
    }

    private fun unlock() { VaultSession.touch(); load() }

    // ---------- Lista ----------
    private fun load() {
        lifecycleScope.launch {
            contacts = withContext(Dispatchers.IO) { repo.hiddenContacts() }
            list.adapter = ArrayAdapter(this@VaultActivity, android.R.layout.simple_list_item_1, contacts)
        }
    }

    private fun confirmUnhide(address: String) {
        AlertDialog.Builder(this)
            .setTitle("Tirar do cofre?")
            .setMessage("As mensagens de $address voltam à lista normal.")
            .setPositiveButton("Tirar") { _, _ ->
                lifecycleScope.launch { withContext(Dispatchers.IO) { repo.unhide(address) }; load() }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
