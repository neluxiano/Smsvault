package com.cosmac.smsvault.security

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * - Passphrase da BD: aleatória, guardada em EncryptedSharedPreferences (chave no Android Keystore).
 *   A BD tem de abrir sem PIN porque SMS chegam com o telemóvel bloqueado.
 * - O PIN protege o ACESSO à interface do cofre (guardado só como hash PBKDF2).
 */
object VaultKeys {
    private fun prefs(ctx: Context) = EncryptedSharedPreferences.create(
        ctx, "vault_keys",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    @Synchronized
    fun dbPassphrase(ctx: Context): ByteArray {
        val p = prefs(ctx)
        var s = p.getString("db", null)
        if (s == null) {
            val raw = ByteArray(32).also { SecureRandom().nextBytes(it) }
            s = Base64.encodeToString(raw, Base64.NO_WRAP)
            p.edit().putString("db", s).apply()
        }
        return s.toByteArray()
    }

    fun hasPin(ctx: Context) = prefs(ctx).contains("pin_hash")

    fun setPin(ctx: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs(ctx).edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", hash(pin, salt))
            .apply()
    }

    fun checkPin(ctx: Context, pin: String): Boolean {
        val p = prefs(ctx)
        val salt = Base64.decode(p.getString("pin_salt", null) ?: return false, Base64.NO_WRAP)
        val expected = p.getString("pin_hash", null) ?: return false
        return MessageDigest.isEqual(expected.toByteArray(), hash(pin, salt).toByteArray())
    }

    private fun hash(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        val h = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.encodeToString(h, Base64.NO_WRAP)
    }
}

/** Cofre fica "aberto" 2 minutos depois de autenticar. */
object VaultSession {
    private var unlockedAt = 0L
    fun touch() { unlockedAt = System.currentTimeMillis() }
    fun valid() = System.currentTimeMillis() - unlockedAt < 2 * 60_000
    fun lock() { unlockedAt = 0L }
}
