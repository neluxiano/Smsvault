package com.cosmac.smsvault.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.cosmac.smsvault.security.VaultSession
import com.cosmac.smsvault.sms.SmsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ThreadActivity : AppCompatActivity() {
    companion object {
        fun open(c: Context, address: String, hidden: Boolean) =
            c.startActivity(Intent(c, ThreadActivity::class.java).putExtra("a", address).putExtra("h", hidden))
    }

    private lateinit var repo: SmsRepository
    private lateinit var list: ListView
    private lateinit var address: String
    private var hidden = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        address = intent.getStringExtra("a") ?: return finish()
        hidden = intent.getBooleanExtra("h", false)
        if (hidden) {
            if (!VaultSession.valid()) return finish()
            window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        }
        title = address
        repo = SmsRepository(this)

        list = ListView(this)
        val input = EditText(this).apply { hint = "Mensagem" }
        val send = Button(this).apply { text = "Enviar" }
        val row = LinearLayout(this).apply {
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(send)
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(row)
        })

        send.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            input.text.clear()
            lifecycleScope.launch {
                withContext(Dispatchers.IO) { repo.send(address, text) }
                load()
            }
        }
    }

    override fun onResume() { super.onResume(); if (hidden) VaultSession.touch(); load() }

    private fun load() {
        lifecycleScope.launch {
            val msgs = withContext(Dispatchers.IO) { repo.thread(address, hidden) }
            list.adapter = ArrayAdapter(
                this@ThreadActivity, android.R.layout.simple_list_item_1,
                msgs.map { (if (it.incoming) "◀ " else "▶ ") + it.body }
            )
            list.setSelection(msgs.size - 1)
        }
    }
}
