package com.cosmac.smsvault.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** contactKey = últimos 9 dígitos do número (ex.: 841234567), igual para +258841234567 e 841234567 */
@Entity(tableName = "hidden_contacts")
data class HiddenContact(
    @PrimaryKey val contactKey: String,
    val address: String
)

@Entity(tableName = "vault_messages")
data class VaultMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactKey: String,
    val address: String,
    val body: String,
    val date: Long,
    val incoming: Boolean
)
