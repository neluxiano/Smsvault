# SMS Cofre — esqueleto (Kotlin)

## Como abrir
1. Android Studio → File → Open → pasta `SmsVault`
2. Aguarde o Gradle sincronizar
3. Corra num telemóvel real (SMS não funciona bem em emulador) com Android 10+
4. Ao abrir, aceite as permissões e defina o app como **app SMS padrão**

## Como usar
- **Esconder:** toque longo numa conversa → "Mover para o cofre"
- **Abrir cofre:** toque longo no título "Mensagens" → PIN (cria-se no 1º uso) ou biometria
- **Tirar do cofre:** toque longo no contacto dentro do cofre

## O que já faz
- App SMS padrão (receivers + service obrigatórios)
- Lista de conversas, ler e enviar SMS
- Cofre em BD cifrada (Room + SQLCipher), chave no Keystore
- Mensagens novas de contactos escondidos vão direto ao cofre
- Notificação genérica ("Nova mensagem") para contactos escondidos
- FLAG_SECURE (sem capturas de ecrã) no cofre
- Cofre fecha ao voltar à lista principal e após 2 min

## Limitações conhecidas / próximos passos
- MMS e grupos: não implementado
- Nomes dos contactos (agora mostra o número)
- Atualização em tempo real da conversa aberta (agora atualiza ao voltar ao ecrã)
- Estado de entrega/erro de envio (PendingIntents)
- Adicionar ao cofre um número sem conversa prévia
- PIN falso (cofre vazio) e ícone/nome disfarçado
- Backup cifrado do cofre (allowBackup=false: se limpar os dados, perde tudo)
- SMS não é cifrado ponta a ponta: a operadora vê tudo. O cofre protege só o telemóvel.
